import subprocess
import time
import json
import pyautogui

from flask import Flask, jsonify

app = Flask(__name__)


@app.route('/')
def hello_world():  # put application's code here
    return 'Fumiamo un J?'


@app.route('/webcam')
def webcam():
    webcam_process = subprocess.Popen(['python', 'camera.py'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)  # apre la finestra con la webcam

    try:
        output, error = webcam_process.communicate(timeout=30)#caso in cui la telecamera viene spenta prima del timeout
    except subprocess.TimeoutExpired:
        webcam_process.terminate() #caso in cui il timeout finisce
        output, error = webcam_process.communicate()

    output_no_json = output.decode().strip('\r\n').split("/") #estrapolazione dell'outpt della webcam

    output_json = []
    i = 0
    for out in output_no_json: # formatting in json
        out.strip("\\r\\n")  # formatting della stringa
        output_item = out.split("\r\n")  # formatting della stringa
        if out != '':
            if i == 0:  # inserimento dati lista formato json
                output_json.append(
                    "{ \"n_side\": " + output_item[0] + ", \"x_mid\": " + output_item[1] +
                    ", \"y_mid\": " + output_item[2] + " }")
                i += 1
            else:
                output_json.append(
                    "{ \"n_side\": " + output_item[1] + ", \"x_mid\": " + output_item[2] +
                    ", \"y_mid\": " + output_item[3] + " }")

    output_filtered = list(set(output_json))  # toglie elementi doppi dalla lista

    return jsonify(output_filtered)


if __name__ == '__main__':
    app.run()
