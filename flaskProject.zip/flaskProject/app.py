from flask import Flask, render_template, jsonify
import subprocess

app = Flask(__name__)

@app.route('/')
def MainPage():
    return render_template('Main.html')

@app.route('/camData')
def findNextPieceCoords():
    webcam_process = subprocess.Popen(['python', 'cameraCam.py'], stdout=subprocess.PIPE,
                                      stderr=subprocess.PIPE)  # apre la finestra con la webcam

    try:
        output, error = webcam_process.communicate(
            timeout=30)  # caso in cui la telecamera viene spenta prima del timeout
    except subprocess.TimeoutExpired:
        webcam_process.terminate()  # caso in cui il timeout finisce
        output, error = webcam_process.communicate()

    output_no_json = output.decode().strip('\r\n').split("/")  # estrapolazione dell'outpt della webcam

    output_json = []
    i = 0
    for out in output_no_json:  # formatting in json
        out.strip("\\r\\n")  # formatting della stringa
        output_item = out.split("\r\n")  # formatting della stringa
        if out != '':
            if i == 0:  # inserimento dati lista formato json
                output_json.append(
                    "{ \"n_side\": " + output_item[0] + ", \"x_mid\": " + output_item[1] +
                    ", \"y_mid\": " + output_item[2] + " }")
                i += 1
            else:
                output_json.append(
                    "{ \"n_side\": " + output_item[1] + ", \"x_mid\": " + output_item[2] +
                    ", \"y_mid\": " + output_item[3] + " }")

    output_filtered = list(set(output_json))  # toglie elementi doppi dalla lista

    return jsonify(output_filtered)
    #return render_template('CameraData.html', xElement=jsonify(output_filtered)[0], yElement=jsonify(output_filtered)[1] )

@app.route('/button_pressed', methods=['POST'])
def button_pressed():
    # chiamata alla funzione my_function()
    my_function()
    return 'Pulsante premuto'

def my_function():
    # codice della funzione qui
    print('La funzione my_function() è stata chiamata')

